import React from 'react';
import { ArrowRight, MoveDown } from 'lucide-react';
import { Button } from './Button';
import { Reveal } from './Reveal';

export const Hero: React.FC = () => {
  return (
    <section id="home" className="min-h-screen flex flex-col pt-32 md:pt-48 pb-20 relative overflow-hidden bg-premium-bg">
      
      {/* Abstract Gradient Background */}
      <div className="absolute top-[-10%] right-[-10%] w-[50vw] h-[50vw] bg-premium-gold/[0.05] rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[40vw] h-[40vw] bg-blue-900/[0.05] rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-[1800px] mx-auto px-6 md:px-12 w-full flex-grow flex flex-col justify-center z-10">
        
        {/* Intro Tag */}
        <Reveal>
          <div className="flex items-center gap-6 mb-8">
            <span className="text-premium-gold uppercase tracking-[0.2em] text-xs font-bold border border-premium-gold/30 px-4 py-2 rounded-full backdrop-blur-sm">
              Disponível para Projetos
            </span>
          </div>
        </Reveal>
        
        {/* Massive Typography */}
        <div className="relative mb-12">
          <Reveal delay={100}>
            <h1 className="font-serif text-6xl sm:text-7xl md:text-[8rem] font-medium text-white tracking-tight leading-[0.9]">
              Digital <br />
              <span className="italic text-premium-dim">Architect</span>
              <span className="text-premium-gold">.</span>
            </h1>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-24 items-start mt-8">
          
          {/* Description */}
          <div className="md:col-span-6 lg:col-span-5">
             <Reveal delay={200}>
               <div className="w-16 h-[1px] bg-premium-gold mb-8"></div>
               <p className="text-premium-dim text-lg md:text-xl font-normal leading-relaxed">
                Transformo complexidade em <strong className="text-white font-medium">experiências digitais de alto impacto</strong>. Especialista em design minimalista e engenharia de software de ponta.
               </p>
               <div className="flex gap-6 mt-10">
                  <Button onClick={() => document.getElementById('contact')?.scrollIntoView({behavior: 'smooth'})}>
                    Iniciar Projeto
                  </Button>
                  <a href="#projects" className="flex items-center gap-3 px-6 py-5 text-xs font-bold uppercase tracking-widest text-white border-b border-transparent hover:border-premium-gold transition-all">
                    Ver Portfolio
                  </a>
               </div>
             </Reveal>
          </div>

          {/* Stats / Visual Element */}
          <div className="md:col-span-6 lg:col-span-7 flex flex-col md:flex-row justify-end items-end pt-8">
            <Reveal delay={400} className="w-full flex justify-end gap-12 md:gap-24 border-t border-white/10 pt-8">
              <div>
                <p className="font-serif text-5xl md:text-6xl text-white mb-2">04<span className="text-premium-gold text-3xl italic">+</span></p>
                <p className="text-premium-dim text-xs font-bold uppercase tracking-widest">Anos Exp.</p>
              </div>
              <div>
                <p className="font-serif text-5xl md:text-6xl text-white mb-2">50<span className="text-premium-gold text-3xl italic">+</span></p>
                <p className="text-premium-dim text-xs font-bold uppercase tracking-widest">Projetos</p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce duration-[3000ms] text-premium-dim/50">
        <MoveDown size={24} />
      </div>
    </section>
  );
};