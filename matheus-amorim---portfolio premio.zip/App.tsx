import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Footer } from './components/Footer';
import { Reveal } from './components/Reveal';

function App() {
  return (
    <div className="min-h-screen bg-premium-bg text-white selection:bg-premium-gold/30 selection:text-white overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <Services />
        {/* Placeholder for future Projects section */}
        <section id="projects" className="py-40 bg-premium-bg relative border-t border-white/10">
            <Reveal className="max-w-[1800px] mx-auto px-6 md:px-12 text-center">
                 <span className="text-premium-gold uppercase tracking-[0.2em] text-xs font-bold mb-6 block">Portfólio Selecionado</span>
                 <h2 className="font-serif text-6xl md:text-8xl text-white mb-12">Em Breve</h2>
                 <p className="text-premium-dim text-xl font-light max-w-2xl mx-auto leading-relaxed">
                    Estou finalizando a curadoria dos meus projetos mais recentes. O objetivo é demonstrar não apenas o resultado visual, mas a estratégia por trás de cada pixel.
                 </p>
            </Reveal>
        </section>
      </main>
      <Footer />
    </div>
  );
}

export default App;